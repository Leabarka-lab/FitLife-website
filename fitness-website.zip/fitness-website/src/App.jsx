import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { 
  Menu, 
  X, 
  Play, 
  Calculator, 
  BookOpen, 
  Users, 
  Mail, 
  Phone, 
  MapPin,
  Star,
  ChevronRight,
  Dumbbell,
  Heart,
  Target,
  Zap,
  Globe,
  Search,
  Filter
} from 'lucide-react'
import CalculatorModal from './components/CalculatorModal.jsx'
import './App.css'

// Import images
import heroImage from './assets/05Qkij7SL9qR.jpg'
import fitnessImage1 from './assets/iJLYamiJPciW.jpg'
import fitnessImage2 from './assets/HVcFe5wPCB8k.jpg'
import fitnessImage3 from './assets/MtW0qzyAirsM.jpg'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [language, setLanguage] = useState('en')
  const [activeSection, setActiveSection] = useState('home')
  const [calculatorModal, setCalculatorModal] = useState({ isOpen: false, type: null })
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedDifficulty, setSelectedDifficulty] = useState('all')

  const translations = {
    en: {
      nav: {
        home: 'Home',
        calculators: 'Calculators',
        education: 'Education',
        videos: 'Videos',
        services: 'Services',
        about: 'About',
        contact: 'Contact'
      },
      hero: {
        title: 'Transform Your Body, Transform Your Life',
        subtitle: 'Join thousands of young adults who have discovered their fitness potential with our comprehensive training programs and expert guidance.',
        cta1: 'Sign Up',
        cta2: 'Create Your Plan'
      },
      calculators: {
        title: 'Fitness Calculators',
        subtitle: 'Get personalized insights into your fitness journey',
        bmi: 'BMI Calculator',
        bmr: 'BMR/TDEE Calculator',
        weight: 'Ideal Weight Calculator',
        bodyfat: 'Body Fat Estimator'
      },
      education: {
        title: 'Educational Resources',
        subtitle: 'Master your fitness with expert guidance',
        strength: 'Strength Training',
        cardio: 'Cardio',
        mobility: 'Mobility',
        hiit: 'HIIT',
        kickboxing: 'Kickboxing',
        skiing: 'Skiing'
      },
      services: {
        title: 'Our Services',
        subtitle: 'Personalized fitness solutions for your goals',
        personal: 'Personal Training',
        coaching: 'Online Coaching',
        programs: 'Custom Programs'
      },
      about: {
        title: 'About FitLife',
        subtitle: 'Your trusted fitness companion since 2020'
      },
      contact: {
        title: 'Get In Touch',
        subtitle: 'Ready to start your fitness journey?'
      }
    },
    hr: {
      nav: {
        home: 'Početna',
        calculators: 'Kalkulatori',
        education: 'Edukacija',
        videos: 'Videoteka',
        services: 'Usluge',
        about: 'O nama',
        contact: 'Kontakt'
      },
      hero: {
        title: 'Transformiraj Tijelo, Transformiraj Život',
        subtitle: 'Pridruži se tisućama mladih koji su otkrili svoj fitness potencijal s našim sveobuhvatnim programima treninga i stručnim vodstvom.',
        cta1: 'Registriraj se',
        cta2: 'Stvori Plan'
      },
      calculators: {
        title: 'Fitness Kalkulatori',
        subtitle: 'Dobij personalizirane uvide u svoj fitness put',
        bmi: 'BMI Kalkulator',
        bmr: 'BMR/TDEE Kalkulator',
        weight: 'Kalkulator Idealne Težine',
        bodyfat: 'Procjena Tjelesne Masti'
      },
      education: {
        title: 'Edukacijski Resursi',
        subtitle: 'Ovladaj fitnessom uz stručno vodstvo',
        strength: 'Trening Snage',
        cardio: 'Kardio',
        mobility: 'Mobilnost',
        hiit: 'HIIT',
        kickboxing: 'Kickboxing',
        skiing: 'Skijanje'
      },
      services: {
        title: 'Naše Usluge',
        subtitle: 'Personalizirane fitness rješenja za tvoje ciljeve',
        personal: 'Personalni Trening',
        coaching: 'Online Coaching',
        programs: 'Prilagođeni Programi'
      },
      about: {
        title: 'O FitLife',
        subtitle: 'Tvoj pouzdani fitness partner od 2020.'
      },
      contact: {
        title: 'Kontaktiraj Nas',
        subtitle: 'Spreman za početak fitness putovanja?'
      }
    }
  }

  const t = translations[language]

  const Navigation = () => (
    <nav className="fixed top-0 left-0 right-0 z-50 nav-blur border-b">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Dumbbell className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold gradient-text">FitLife</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {Object.entries(t.nav).map(([key, value]) => (
              <button
                key={key}
                onClick={() => setActiveSection(key)}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  activeSection === key ? 'text-primary' : 'text-muted-foreground'
                }`}
              >
                {value}
              </button>
            ))}
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setLanguage(language === 'en' ? 'hr' : 'en')}
                className="flex items-center space-x-1"
              >
                <Globe className="h-4 w-4" />
                <span>{language.toUpperCase()}</span>
              </Button>
            </div>
          </div>

          <button
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-background border-t">
          <div className="container mx-auto px-4 py-4 space-y-4">
            {Object.entries(t.nav).map(([key, value]) => (
              <button
                key={key}
                onClick={() => {
                  setActiveSection(key)
                  setIsMenuOpen(false)
                }}
                className="block w-full text-left text-sm font-medium text-muted-foreground hover:text-primary"
              >
                {value}
              </button>
            ))}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLanguage(language === 'en' ? 'hr' : 'en')}
              className="flex items-center space-x-1"
            >
              <Globe className="h-4 w-4" />
              <span>{language.toUpperCase()}</span>
            </Button>
          </div>
        </div>
      )}
    </nav>
  )

  const HeroSection = () => (
    <section className="hero-section flex items-center justify-center">
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      />
      <div className="hero-overlay" />
      <div className="hero-content container mx-auto px-4 text-center text-white">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 text-shadow">
          {t.hero.title}
        </h1>
        <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto text-shadow">
          {t.hero.subtitle}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
            {t.hero.cta1}
          </Button>
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
            {t.hero.cta2}
          </Button>
        </div>
      </div>
    </section>
  )

  const CalculatorsSection = () => (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">
            {t.calculators.title}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t.calculators.subtitle}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { key: 'bmi', icon: Calculator, title: t.calculators.bmi, type: 'bmi' },
            { key: 'bmr', icon: Heart, title: t.calculators.bmr, type: 'bmr' },
            { key: 'weight', icon: Target, title: t.calculators.weight, type: 'weight' },
            { key: 'bodyfat', icon: Zap, title: t.calculators.bodyfat, type: 'bodyfat' }
          ].map(({ key, icon: Icon, title, type }) => (
            <Card key={key} className="calculator-card cursor-pointer">
              <CardHeader className="text-center">
                <Icon className="h-12 w-12 mx-auto mb-4 feature-icon" />
                <CardTitle className="text-lg">{title}</CardTitle>
              </CardHeader>
              <CardContent>
                <Button 
                  className="w-full" 
                  variant="outline"
                  onClick={() => setCalculatorModal({ isOpen: true, type })}
                >
                  Calculate Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )

  const EducationSection = () => {
    const educationContent = [
      { key: 'strength', title: t.education.strength, image: fitnessImage1, category: 'strength', difficulty: 'intermediate' },
      { key: 'cardio', title: t.education.cardio, image: fitnessImage2, category: 'cardio', difficulty: 'beginner' },
      { key: 'mobility', title: t.education.mobility, image: fitnessImage3, category: 'mobility', difficulty: 'beginner' },
      { key: 'hiit', title: t.education.hiit, image: fitnessImage1, category: 'hiit', difficulty: 'advanced' },
      { key: 'kickboxing', title: t.education.kickboxing, image: fitnessImage2, category: 'kickboxing', difficulty: 'intermediate' },
      { key: 'skiing', title: t.education.skiing, image: fitnessImage3, category: 'skiing', difficulty: 'intermediate' }
    ]

    const filteredContent = educationContent.filter(item => {
      const matchesSearch = item.title.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory
      const matchesDifficulty = selectedDifficulty === 'all' || item.difficulty === selectedDifficulty
      return matchesSearch && matchesCategory && matchesDifficulty
    })

    return (
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">
              {t.education.title}
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t.education.subtitle}
            </p>
          </div>
          
          {/* Search and Filter Controls */}
          <div className="mb-8 space-y-4">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              <div className="flex gap-2">
                <Button
                  variant={selectedCategory === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory('all')}
                >
                  All
                </Button>
                {['strength', 'cardio', 'mobility', 'hiit', 'kickboxing', 'skiing'].map(category => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedCategory(category)}
                    className="capitalize"
                  >
                    {category}
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex gap-2 justify-center">
              <Button
                variant={selectedDifficulty === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedDifficulty('all')}
              >
                All Levels
              </Button>
              {['beginner', 'intermediate', 'advanced'].map(difficulty => (
                <Button
                  key={difficulty}
                  variant={selectedDifficulty === difficulty ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedDifficulty(difficulty)}
                  className="capitalize"
                >
                  {difficulty}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredContent.map(({ key, title, image, difficulty }) => (
              <Card key={key} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video relative overflow-hidden">
                  <img 
                    src={image} 
                    alt={title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <Button variant="secondary" size="sm">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Learn More
                    </Button>
                  </div>
                  <Badge className="absolute top-2 right-2 capitalize">
                    {difficulty}
                  </Badge>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{title}</CardTitle>
                  <CardDescription>
                    Comprehensive guides and expert tips for {title.toLowerCase()}.
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
          
          {filteredContent.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No articles found matching your criteria.</p>
            </div>
          )}
        </div>
      </section>
    )
  }

  const ServicesSection = () => (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">
            {t.services.title}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t.services.subtitle}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { 
              title: t.services.personal, 
              price: '$99/month',
              features: ['1-on-1 Training', 'Custom Workout Plans', 'Nutrition Guidance', '24/7 Support']
            },
            { 
              title: t.services.coaching, 
              price: '$49/month',
              features: ['Online Sessions', 'Progress Tracking', 'Weekly Check-ins', 'Community Access']
            },
            { 
              title: t.services.programs, 
              price: '$29/month',
              features: ['Pre-built Programs', 'Video Demonstrations', 'Progress Analytics', 'Mobile App']
            }
          ].map((service, index) => (
            <Card key={index} className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <CardTitle className="text-2xl">{service.title}</CardTitle>
                <div className="text-3xl font-bold text-primary">{service.price}</div>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center justify-center space-x-2">
                      <Star className="h-4 w-4 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button className="w-full">Get Started</Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )

  const AboutSection = () => (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">
            {t.about.title}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t.about.subtitle}
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <img 
              src={fitnessImage2} 
              alt="About FitLife"
              className="w-full rounded-lg shadow-lg"
            />
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-bold">Our Mission</h3>
            <p className="text-muted-foreground">
              At FitLife, we believe that fitness is not just about physical transformation—it's about building confidence, 
              creating healthy habits, and empowering young adults to live their best lives. Our team of certified trainers 
              and nutritionists work together to provide you with the tools, knowledge, and support you need to succeed.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">10K+</div>
                <div className="text-sm text-muted-foreground">Happy Members</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">500+</div>
                <div className="text-sm text-muted-foreground">Success Stories</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )

  const ContactSection = () => (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">
            {t.contact.title}
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            {t.contact.subtitle}
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <Card>
            <CardHeader>
              <CardTitle>Send us a message</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="John" />
                </div>
                <div>
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Doe" />
                </div>
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="john@example.com" />
              </div>
              <div>
                <Label htmlFor="message">Message</Label>
                <Textarea id="message" placeholder="Tell us about your fitness goals..." />
              </div>
              <Button className="w-full">Send Message</Button>
            </CardContent>
          </Card>
          
          <div className="space-y-8">
            <div className="flex items-start space-x-4">
              <Mail className="h-6 w-6 text-primary mt-1" />
              <div>
                <h4 className="font-semibold">Email</h4>
                <p className="text-muted-foreground">hello@fitlife.com</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <Phone className="h-6 w-6 text-primary mt-1" />
              <div>
                <h4 className="font-semibold">Phone</h4>
                <p className="text-muted-foreground">+1 (555) 123-4567</p>
              </div>
            </div>
            <div className="flex items-start space-x-4">
              <MapPin className="h-6 w-6 text-primary mt-1" />
              <div>
                <h4 className="font-semibold">Address</h4>
                <p className="text-muted-foreground">123 Fitness Street<br />Health City, HC 12345</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )

  const Footer = () => (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Dumbbell className="h-6 w-6" />
              <span className="text-lg font-bold">FitLife</span>
            </div>
            <p className="text-sm opacity-80">
              Transform your body, transform your life with our comprehensive fitness programs.
            </p>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><a href="#" className="hover:opacity-100">Home</a></li>
              <li><a href="#" className="hover:opacity-100">Calculators</a></li>
              <li><a href="#" className="hover:opacity-100">Education</a></li>
              <li><a href="#" className="hover:opacity-100">Services</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><a href="#" className="hover:opacity-100">Help Center</a></li>
              <li><a href="#" className="hover:opacity-100">Contact Us</a></li>
              <li><a href="#" className="hover:opacity-100">Privacy Policy</a></li>
              <li><a href="#" className="hover:opacity-100">Terms of Service</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Follow Us</h4>
            <div className="flex space-x-4">
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/20">
                Facebook
              </Button>
              <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-primary-foreground/20">
                Instagram
              </Button>
            </div>
          </div>
        </div>
        <div className="border-t border-primary-foreground/20 mt-8 pt-8 text-center text-sm opacity-80">
          <p>&copy; 2024 FitLife. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )

  const renderSection = () => {
    switch (activeSection) {
      case 'home':
        return (
          <>
            <HeroSection />
            <CalculatorsSection />
            <EducationSection />
            <ServicesSection />
          </>
        )
      case 'calculators':
        return <CalculatorsSection />
      case 'education':
        return <EducationSection />
      case 'services':
        return <ServicesSection />
      case 'about':
        return <AboutSection />
      case 'contact':
        return <ContactSection />
      default:
        return (
          <>
            <HeroSection />
            <CalculatorsSection />
            <EducationSection />
            <ServicesSection />
          </>
        )
    }
  }

  return (
    <div className="min-h-screen">
      <Navigation />
      <main className="pt-16">
        {renderSection()}
      </main>
      <Footer />
      
      {/* Floating CTA */}
      <div className="floating-cta">
        <Button size="lg" className="rounded-full shadow-lg">
          <ChevronRight className="h-5 w-5 ml-1" />
          Start Now
        </Button>
      </div>

      {/* Calculator Modal */}
      <CalculatorModal
        isOpen={calculatorModal.isOpen}
        onClose={() => setCalculatorModal({ isOpen: false, type: null })}
        calculatorType={calculatorModal.type}
        language={language}
      />
    </div>
  )
}

export default App

