import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx'
import { Target } from 'lucide-react'

const IdealWeightCalculator = ({ language = 'en' }) => {
  const [height, setHeight] = useState('')
  const [gender, setGender] = useState('')
  const [unit, setUnit] = useState('metric')
  const [result, setResult] = useState(null)

  const translations = {
    en: {
      title: 'Ideal Weight Calculator',
      description: 'Calculate your ideal weight range using multiple formulas',
      height: 'Height',
      gender: 'Gender',
      male: 'Male',
      female: 'Female',
      units: 'Units',
      metric: 'Metric (cm/kg)',
      imperial: 'Imperial (in/lbs)',
      calculate: 'Calculate Ideal Weight',
      result: 'Your Ideal Weight Range',
      formulas: {
        hamwi: 'Hamwi Formula',
        devine: 'Devine Formula',
        robinson: 'Robinson Formula',
        miller: 'Miller Formula'
      },
      explanation: 'These formulas provide different estimates of ideal weight. Your actual ideal weight may vary based on body composition, muscle mass, and other factors.'
    },
    hr: {
      title: 'Kalkulator Idealne Težine',
      description: 'Izračunajte svoj raspon idealne težine koristeći više formula',
      height: 'Visina',
      gender: 'Spol',
      male: 'Muški',
      female: 'Ženski',
      units: 'Jedinice',
      metric: 'Metrički (cm/kg)',
      imperial: 'Imperijalni (in/lbs)',
      calculate: 'Izračunaj Idealnu Težinu',
      result: 'Vaš Raspon Idealne Težine',
      formulas: {
        hamwi: 'Hamwi Formula',
        devine: 'Devine Formula',
        robinson: 'Robinson Formula',
        miller: 'Miller Formula'
      },
      explanation: 'Ove formule pružaju različite procjene idealne težine. Vaša stvarna idealna težina može varirati na osnovu sastava tijela, mišićne mase i drugih faktora.'
    }
  }

  const t = translations[language]

  const calculateIdealWeight = () => {
    if (!height || !gender) return

    let heightInInches
    if (unit === 'metric') {
      heightInInches = parseFloat(height) / 2.54
    } else {
      heightInInches = parseFloat(height)
    }

    const results = {}

    // Hamwi Formula
    if (gender === 'male') {
      results.hamwi = 106 + 6 * (heightInInches - 60)
    } else {
      results.hamwi = 100 + 5 * (heightInInches - 60)
    }

    // Devine Formula
    if (gender === 'male') {
      results.devine = 110 + 5 * (heightInInches - 60)
    } else {
      results.devine = 100 + 3.5 * (heightInInches - 60)
    }

    // Robinson Formula
    if (gender === 'male') {
      results.robinson = 114 + 4.2 * (heightInInches - 60)
    } else {
      results.robinson = 108 + 3.7 * (heightInInches - 60)
    }

    // Miller Formula
    if (gender === 'male') {
      results.miller = 117 + 4 * (heightInInches - 60)
    } else {
      results.miller = 111 + 3 * (heightInInches - 60)
    }

    // Convert to kg if metric
    if (unit === 'metric') {
      Object.keys(results).forEach(key => {
        results[key] = results[key] * 0.453592
      })
    }

    // Calculate range
    const weights = Object.values(results)
    const minWeight = Math.min(...weights)
    const maxWeight = Math.max(...weights)

    setResult({
      formulas: results,
      range: {
        min: Math.round(minWeight),
        max: Math.round(maxWeight)
      },
      unit: unit === 'metric' ? 'kg' : 'lbs'
    })
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <Target className="h-12 w-12 mx-auto mb-4 text-primary" />
        <CardTitle className="text-xl">{t.title}</CardTitle>
        <CardDescription>{t.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="units">{t.units}</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="metric">{t.metric}</SelectItem>
              <SelectItem value="imperial">{t.imperial}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>{t.gender}</Label>
          <RadioGroup value={gender} onValueChange={setGender} className="flex space-x-4 mt-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">{t.male}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">{t.female}</Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label htmlFor="height">
            {t.height} ({unit === 'metric' ? 'cm' : 'inches'})
          </Label>
          <Input
            id="height"
            type="number"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder={unit === 'metric' ? '170' : '67'}
          />
        </div>

        <Button onClick={calculateIdealWeight} className="w-full">
          {t.calculate}
        </Button>

        {result && (
          <div className="mt-6 space-y-4">
            <div className="p-4 bg-primary/10 rounded-lg text-center">
              <h3 className="font-semibold text-lg mb-2">{t.result}</h3>
              <div className="text-2xl font-bold text-primary mb-2">
                {result.range.min} - {result.range.max} {result.unit}
              </div>
            </div>
            
            <div className="space-y-2">
              {Object.entries(result.formulas).map(([formula, weight]) => (
                <div key={formula} className="flex justify-between items-center p-2 bg-muted rounded">
                  <span className="text-sm font-medium">{t.formulas[formula]}</span>
                  <span className="font-semibold">
                    {Math.round(weight)} {result.unit}
                  </span>
                </div>
              ))}
            </div>
            
            <p className="text-sm text-muted-foreground">
              {t.explanation}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default IdealWeightCalculator

