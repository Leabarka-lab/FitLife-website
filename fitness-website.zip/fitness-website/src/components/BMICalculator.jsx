import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Calculator } from 'lucide-react'

const BMICalculator = ({ language = 'en' }) => {
  const [height, setHeight] = useState('')
  const [weight, setWeight] = useState('')
  const [unit, setUnit] = useState('metric')
  const [result, setResult] = useState(null)

  const translations = {
    en: {
      title: 'BMI Calculator',
      description: 'Calculate your Body Mass Index to assess your weight status',
      height: 'Height',
      weight: 'Weight',
      units: 'Units',
      metric: 'Metric (cm/kg)',
      imperial: 'Imperial (in/lbs)',
      calculate: 'Calculate BMI',
      result: 'Your BMI Result',
      category: 'Category',
      categories: {
        underweight: 'Underweight',
        normal: 'Normal Weight',
        overweight: 'Overweight',
        obese: 'Obese'
      },
      explanation: 'BMI is a measure of body fat based on height and weight. It provides a general indication of whether you have a healthy weight for your height.'
    },
    hr: {
      title: 'BMI Kalkulator',
      description: 'Izračunajte svoj indeks tjelesne mase za procjenu statusa težine',
      height: 'Visina',
      weight: 'Težina',
      units: 'Jedinice',
      metric: 'Metrički (cm/kg)',
      imperial: 'Imperijalni (in/lbs)',
      calculate: 'Izračunaj BMI',
      result: 'Vaš BMI Rezultat',
      category: 'Kategorija',
      categories: {
        underweight: 'Pothranjen',
        normal: 'Normalna Težina',
        overweight: 'Prekomjerna Težina',
        obese: 'Pretil'
      },
      explanation: 'BMI je mjera tjelesne masti na osnovu visine i težine. Pruža opću indikaciju da li imate zdravu težinu za svoju visinu.'
    }
  }

  const t = translations[language]

  const calculateBMI = () => {
    if (!height || !weight) return

    let heightInM, weightInKg

    if (unit === 'metric') {
      heightInM = parseFloat(height) / 100
      weightInKg = parseFloat(weight)
    } else {
      heightInM = parseFloat(height) * 0.0254
      weightInKg = parseFloat(weight) * 0.453592
    }

    const bmi = weightInKg / (heightInM * heightInM)
    
    let category, color
    if (bmi < 18.5) {
      category = t.categories.underweight
      color = 'bg-blue-100 text-blue-800'
    } else if (bmi < 25) {
      category = t.categories.normal
      color = 'bg-green-100 text-green-800'
    } else if (bmi < 30) {
      category = t.categories.overweight
      color = 'bg-yellow-100 text-yellow-800'
    } else {
      category = t.categories.obese
      color = 'bg-red-100 text-red-800'
    }

    setResult({
      bmi: bmi.toFixed(1),
      category,
      color
    })
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <Calculator className="h-12 w-12 mx-auto mb-4 text-primary" />
        <CardTitle className="text-xl">{t.title}</CardTitle>
        <CardDescription>{t.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="units">{t.units}</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="metric">{t.metric}</SelectItem>
              <SelectItem value="imperial">{t.imperial}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="height">
            {t.height} ({unit === 'metric' ? 'cm' : 'inches'})
          </Label>
          <Input
            id="height"
            type="number"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder={unit === 'metric' ? '170' : '67'}
          />
        </div>

        <div>
          <Label htmlFor="weight">
            {t.weight} ({unit === 'metric' ? 'kg' : 'lbs'})
          </Label>
          <Input
            id="weight"
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder={unit === 'metric' ? '70' : '154'}
          />
        </div>

        <Button onClick={calculateBMI} className="w-full">
          {t.calculate}
        </Button>

        {result && (
          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h3 className="font-semibold text-lg mb-2">{t.result}</h3>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold text-primary">{result.bmi}</span>
              <Badge className={result.color}>{result.category}</Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              {t.explanation}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default BMICalculator

