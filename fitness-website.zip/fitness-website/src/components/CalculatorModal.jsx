import React from 'react'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog.jsx'
import BMICalculator from './BMICalculator.jsx'
import BMRCalculator from './BMRCalculator.jsx'
import IdealWeightCalculator from './IdealWeightCalculator.jsx'
import BodyFatCalculator from './BodyFatCalculator.jsx'

const CalculatorModal = ({ isOpen, onClose, calculatorType, language }) => {
  const renderCalculator = () => {
    switch (calculatorType) {
      case 'bmi':
        return <BMICalculator language={language} />
      case 'bmr':
        return <BMRCalculator language={language} />
      case 'weight':
        return <IdealWeightCalculator language={language} />
      case 'bodyfat':
        return <BodyFatCalculator language={language} />
      default:
        return null
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        {renderCalculator()}
      </DialogContent>
    </Dialog>
  )
}

export default CalculatorModal

