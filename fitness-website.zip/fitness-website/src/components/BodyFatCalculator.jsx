import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Zap } from 'lucide-react'

const BodyFatCalculator = ({ language = 'en' }) => {
  const [age, setAge] = useState('')
  const [gender, setGender] = useState('')
  const [neck, setNeck] = useState('')
  const [waist, setWaist] = useState('')
  const [hip, setHip] = useState('')
  const [unit, setUnit] = useState('metric')
  const [result, setResult] = useState(null)

  const translations = {
    en: {
      title: 'Body Fat Estimator',
      description: 'Estimate your body fat percentage using the Navy method',
      age: 'Age',
      gender: 'Gender',
      male: 'Male',
      female: 'Female',
      neck: 'Neck Circumference',
      waist: 'Waist Circumference',
      hip: 'Hip Circumference',
      units: 'Units',
      metric: 'Metric (cm)',
      imperial: 'Imperial (inches)',
      calculate: 'Calculate Body Fat',
      result: 'Your Body Fat Percentage',
      categories: {
        essential: 'Essential Fat',
        athletes: 'Athletes',
        fitness: 'Fitness',
        acceptable: 'Acceptable',
        obese: 'Obese'
      },
      explanation: 'This calculation uses the U.S. Navy method. Results are estimates and may vary. For accurate measurements, consult a healthcare professional.',
      hipNote: 'Hip measurement is required for women only'
    },
    hr: {
      title: 'Procjena Tjelesne Masti',
      description: 'Procijenite postotak tjelesne masti koristeći Navy metodu',
      age: 'Godine',
      gender: 'Spol',
      male: 'Muški',
      female: 'Ženski',
      neck: 'Opseg Vrata',
      waist: 'Opseg Struka',
      hip: 'Opseg Bokova',
      units: 'Jedinice',
      metric: 'Metrički (cm)',
      imperial: 'Imperijalni (inči)',
      calculate: 'Izračunaj Tjelesnu Mast',
      result: 'Vaš Postotak Tjelesne Masti',
      categories: {
        essential: 'Esencijalna Mast',
        athletes: 'Sportaši',
        fitness: 'Fitness',
        acceptable: 'Prihvatljivo',
        obese: 'Pretilost'
      },
      explanation: 'Ovaj izračun koristi U.S. Navy metodu. Rezultati su procjene i mogu varirati. Za točne mjerenja, konzultirajte zdravstvenog stručnjaka.',
      hipNote: 'Mjerenje bokova je potrebno samo za žene'
    }
  }

  const t = translations[language]

  const getBodyFatCategory = (bodyFat, gender) => {
    if (gender === 'male') {
      if (bodyFat < 6) return { category: t.categories.essential, color: 'bg-blue-100 text-blue-800' }
      if (bodyFat < 14) return { category: t.categories.athletes, color: 'bg-green-100 text-green-800' }
      if (bodyFat < 18) return { category: t.categories.fitness, color: 'bg-green-100 text-green-800' }
      if (bodyFat < 25) return { category: t.categories.acceptable, color: 'bg-yellow-100 text-yellow-800' }
      return { category: t.categories.obese, color: 'bg-red-100 text-red-800' }
    } else {
      if (bodyFat < 16) return { category: t.categories.essential, color: 'bg-blue-100 text-blue-800' }
      if (bodyFat < 20) return { category: t.categories.athletes, color: 'bg-green-100 text-green-800' }
      if (bodyFat < 25) return { category: t.categories.fitness, color: 'bg-green-100 text-green-800' }
      if (bodyFat < 32) return { category: t.categories.acceptable, color: 'bg-yellow-100 text-yellow-800' }
      return { category: t.categories.obese, color: 'bg-red-100 text-red-800' }
    }
  }

  const calculateBodyFat = () => {
    if (!age || !gender || !neck || !waist || (gender === 'female' && !hip)) return

    let neckCm, waistCm, hipCm

    if (unit === 'metric') {
      neckCm = parseFloat(neck)
      waistCm = parseFloat(waist)
      hipCm = hip ? parseFloat(hip) : 0
    } else {
      neckCm = parseFloat(neck) * 2.54
      waistCm = parseFloat(waist) * 2.54
      hipCm = hip ? parseFloat(hip) * 2.54 : 0
    }

    let bodyFat

    if (gender === 'male') {
      // Navy formula for men
      bodyFat = 495 / (1.0324 - 0.19077 * Math.log10(waistCm - neckCm) + 0.15456 * Math.log10(170)) - 450
    } else {
      // Navy formula for women
      bodyFat = 495 / (1.29579 - 0.35004 * Math.log10(waistCm + hipCm - neckCm) + 0.22100 * Math.log10(170)) - 450
    }

    const category = getBodyFatCategory(bodyFat, gender)

    setResult({
      bodyFat: bodyFat.toFixed(1),
      category: category.category,
      color: category.color
    })
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <Zap className="h-12 w-12 mx-auto mb-4 text-primary" />
        <CardTitle className="text-xl">{t.title}</CardTitle>
        <CardDescription>{t.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="units">{t.units}</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="metric">{t.metric}</SelectItem>
              <SelectItem value="imperial">{t.imperial}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>{t.gender}</Label>
          <RadioGroup value={gender} onValueChange={setGender} className="flex space-x-4 mt-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">{t.male}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">{t.female}</Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label htmlFor="age">{t.age}</Label>
          <Input
            id="age"
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="25"
          />
        </div>

        <div>
          <Label htmlFor="neck">
            {t.neck} ({unit === 'metric' ? 'cm' : 'inches'})
          </Label>
          <Input
            id="neck"
            type="number"
            step="0.1"
            value={neck}
            onChange={(e) => setNeck(e.target.value)}
            placeholder={unit === 'metric' ? '37' : '14.5'}
          />
        </div>

        <div>
          <Label htmlFor="waist">
            {t.waist} ({unit === 'metric' ? 'cm' : 'inches'})
          </Label>
          <Input
            id="waist"
            type="number"
            step="0.1"
            value={waist}
            onChange={(e) => setWaist(e.target.value)}
            placeholder={unit === 'metric' ? '85' : '33.5'}
          />
        </div>

        {gender === 'female' && (
          <div>
            <Label htmlFor="hip">
              {t.hip} ({unit === 'metric' ? 'cm' : 'inches'})
            </Label>
            <Input
              id="hip"
              type="number"
              step="0.1"
              value={hip}
              onChange={(e) => setHip(e.target.value)}
              placeholder={unit === 'metric' ? '95' : '37.5'}
            />
            <p className="text-xs text-muted-foreground mt-1">{t.hipNote}</p>
          </div>
        )}

        <Button onClick={calculateBodyFat} className="w-full">
          {t.calculate}
        </Button>

        {result && (
          <div className="mt-6 p-4 bg-muted rounded-lg">
            <h3 className="font-semibold text-lg mb-2">{t.result}</h3>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold text-primary">{result.bodyFat}%</span>
              <Badge className={result.color}>{result.category}</Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-4">
              {t.explanation}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default BodyFatCalculator

