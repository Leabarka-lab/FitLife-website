import React, { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group.jsx'
import { Heart } from 'lucide-react'

const BMRCalculator = ({ language = 'en' }) => {
  const [age, setAge] = useState('')
  const [height, setHeight] = useState('')
  const [weight, setWeight] = useState('')
  const [gender, setGender] = useState('')
  const [activityLevel, setActivityLevel] = useState('')
  const [unit, setUnit] = useState('metric')
  const [result, setResult] = useState(null)

  const translations = {
    en: {
      title: 'BMR/TDEE Calculator',
      description: 'Calculate your Basal Metabolic Rate and Total Daily Energy Expenditure',
      age: 'Age',
      height: 'Height',
      weight: 'Weight',
      gender: 'Gender',
      male: 'Male',
      female: 'Female',
      activity: 'Activity Level',
      units: 'Units',
      metric: 'Metric (cm/kg)',
      imperial: 'Imperial (in/lbs)',
      calculate: 'Calculate BMR/TDEE',
      bmrResult: 'Your BMR',
      tdeeResult: 'Your TDEE',
      calories: 'calories/day',
      bmrExplanation: 'BMR is the number of calories your body needs at rest to maintain basic physiological functions.',
      tdeeExplanation: 'TDEE is your total daily energy expenditure including physical activity.',
      activities: {
        sedentary: 'Sedentary (little/no exercise)',
        light: 'Lightly active (light exercise 1-3 days/week)',
        moderate: 'Moderately active (moderate exercise 3-5 days/week)',
        very: 'Very active (hard exercise 6-7 days/week)',
        extra: 'Extra active (very hard exercise, physical job)'
      }
    },
    hr: {
      title: 'BMR/TDEE Kalkulator',
      description: 'Izračunajte svoju bazalnu metaboličku stopu i ukupnu dnevnu potrošnju energije',
      age: 'Godine',
      height: 'Visina',
      weight: 'Težina',
      gender: 'Spol',
      male: 'Muški',
      female: 'Ženski',
      activity: 'Razina Aktivnosti',
      units: 'Jedinice',
      metric: 'Metrički (cm/kg)',
      imperial: 'Imperijalni (in/lbs)',
      calculate: 'Izračunaj BMR/TDEE',
      bmrResult: 'Vaš BMR',
      tdeeResult: 'Vaš TDEE',
      calories: 'kalorija/dan',
      bmrExplanation: 'BMR je broj kalorija koje vaše tijelo treba u mirovanju za održavanje osnovnih fizioloških funkcija.',
      tdeeExplanation: 'TDEE je vaša ukupna dnevna potrošnja energije uključujući fizičku aktivnost.',
      activities: {
        sedentary: 'Sjedilački (malo/bez vježbanja)',
        light: 'Lagano aktivan (lagano vježbanje 1-3 dana/tjedan)',
        moderate: 'Umjereno aktivan (umjereno vježbanje 3-5 dana/tjedan)',
        very: 'Vrlo aktivan (intenzivno vježbanje 6-7 dana/tjedan)',
        extra: 'Izuzetno aktivan (vrlo intenzivno vježbanje, fizički posao)'
      }
    }
  }

  const t = translations[language]

  const activityMultipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    very: 1.725,
    extra: 1.9
  }

  const calculateBMR = () => {
    if (!age || !height || !weight || !gender || !activityLevel) return

    let heightInCm, weightInKg

    if (unit === 'metric') {
      heightInCm = parseFloat(height)
      weightInKg = parseFloat(weight)
    } else {
      heightInCm = parseFloat(height) * 2.54
      weightInKg = parseFloat(weight) * 0.453592
    }

    const ageNum = parseFloat(age)

    // Mifflin-St Jeor Equation
    let bmr
    if (gender === 'male') {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum + 5
    } else {
      bmr = 10 * weightInKg + 6.25 * heightInCm - 5 * ageNum - 161
    }

    const tdee = bmr * activityMultipliers[activityLevel]

    setResult({
      bmr: Math.round(bmr),
      tdee: Math.round(tdee)
    })
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <Heart className="h-12 w-12 mx-auto mb-4 text-primary" />
        <CardTitle className="text-xl">{t.title}</CardTitle>
        <CardDescription>{t.description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="units">{t.units}</Label>
          <Select value={unit} onValueChange={setUnit}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="metric">{t.metric}</SelectItem>
              <SelectItem value="imperial">{t.imperial}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>{t.gender}</Label>
          <RadioGroup value={gender} onValueChange={setGender} className="flex space-x-4 mt-2">
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="male" id="male" />
              <Label htmlFor="male">{t.male}</Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="female" id="female" />
              <Label htmlFor="female">{t.female}</Label>
            </div>
          </RadioGroup>
        </div>

        <div>
          <Label htmlFor="age">{t.age}</Label>
          <Input
            id="age"
            type="number"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            placeholder="25"
          />
        </div>

        <div>
          <Label htmlFor="height">
            {t.height} ({unit === 'metric' ? 'cm' : 'inches'})
          </Label>
          <Input
            id="height"
            type="number"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            placeholder={unit === 'metric' ? '170' : '67'}
          />
        </div>

        <div>
          <Label htmlFor="weight">
            {t.weight} ({unit === 'metric' ? 'kg' : 'lbs'})
          </Label>
          <Input
            id="weight"
            type="number"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder={unit === 'metric' ? '70' : '154'}
          />
        </div>

        <div>
          <Label htmlFor="activity">{t.activity}</Label>
          <Select value={activityLevel} onValueChange={setActivityLevel}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(t.activities).map(([key, value]) => (
                <SelectItem key={key} value={key}>{value}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button onClick={calculateBMR} className="w-full">
          {t.calculate}
        </Button>

        {result && (
          <div className="mt-6 space-y-4">
            <div className="p-4 bg-muted rounded-lg">
              <h3 className="font-semibold text-lg mb-2">{t.bmrResult}</h3>
              <div className="text-2xl font-bold text-primary mb-2">
                {result.bmr} {t.calories}
              </div>
              <p className="text-sm text-muted-foreground">
                {t.bmrExplanation}
              </p>
            </div>
            
            <div className="p-4 bg-primary/10 rounded-lg">
              <h3 className="font-semibold text-lg mb-2">{t.tdeeResult}</h3>
              <div className="text-2xl font-bold text-primary mb-2">
                {result.tdee} {t.calories}
              </div>
              <p className="text-sm text-muted-foreground">
                {t.tdeeExplanation}
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

export default BMRCalculator

